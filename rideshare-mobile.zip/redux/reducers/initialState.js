const initialState = {
	user: {
		userData: [],
		location: null,
		status: null,
		deviceToken: null,
	},
};

export { initialState };
