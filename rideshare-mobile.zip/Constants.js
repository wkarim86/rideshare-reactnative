export const API_URL = "http://dev.rchem.com.pk/api/";

export const I_CAN_SHARE_RIDE = 1;
export const I_CANNOT_SHARE_RIDE = 2;
export const I_NEED_RIDE = 3;
